import { PrismaClient } from "../generated/prisma/client.js";
import { PrismaPg } from "@prisma/adapter-pg";
import { Pool } from "pg";

const globalForPrisma = globalThis as unknown as {
    prisma: PrismaClient | undefined;
}

function createPrismaClient(): PrismaClient{
    const pool = new Pool({
        connectionString: process.env.DATABASE_URL
    })

    const adapter = new PrismaPg(pool)

    return new PrismaClient({ adapter })
}

const prisma = globalForPrisma.prisma ?? createPrismaClient();

if(process.env.NODE_ENV !== "production"){
    globalForPrisma.prisma = prisma
}

export { prisma }