import { apiRequest } from "../lib/api-client";
import type { PaginationQuery, UpdateUserInput, User } from "../types/api";

export const usersApi = {
  list: (query?: PaginationQuery) => apiRequest<User[]>("/users", { query }),

  me: () => apiRequest<User>("/users/me"),

  getById: (id: string) => apiRequest<User>(`/users/${id}`),

  update: (id: string, input: UpdateUserInput) =>
    apiRequest<User>(`/users/${id}`, { method: "PATCH", body: input }),

  remove: (id: string) =>
    apiRequest<{ id: string }>(`/users/${id}`, { method: "DELETE" }),
};
