// ---------------------------------------------------------------------------
// Shared API types — mirrors the Prisma models / zod schemas in the server
// ---------------------------------------------------------------------------

export type Role = "USER" | "ADMIN"; // adjust to match your Prisma $Enums.Role
export type SessionRole = "GUEST" | "HOST";

export interface ApiSuccess<T> {
  success: true;
  data: T;
  meta?: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  };
}

export interface ApiErrorBody {
  error: string;
  details?: unknown;
}

export interface PaginationQuery {
  page?: number;
  limit?: number;
}

// ---------------------------------------------------------------------------
// User
// ---------------------------------------------------------------------------
export interface User {
  id: string;
  name: string;
  email: string;
  emailVerified: boolean;
  image: string | null;
  createdAt: string;
  updatedAt: string;
  role: Role;
  premiumUntil: string | null;
}

export interface UpdateUserInput {
  name?: string;
  image?: string;
}

// ---------------------------------------------------------------------------
// Song
// ---------------------------------------------------------------------------
export interface Song {
  id: string;
  title: string;
  artist: string;
  coverUrl: string | null;
  audioUrl: string;
  duration: number;
  createdAt: string;
}

export interface CreateSongInput {
  title: string;
  artist: string;
  coverUrl?: string;
  audioUrl: string;
  duration: number;
}

export type UpdateSongInput = Partial<CreateSongInput>;

// ---------------------------------------------------------------------------
// LikedSong
// ---------------------------------------------------------------------------
export interface LikedSong {
  userId: string;
  songId: string;
  likedAt: string;
  song?: Song;
}

// ---------------------------------------------------------------------------
// Album
// ---------------------------------------------------------------------------
export interface Album {
  id: string;
  name: string;
  ownerId: string;
  isCollaborative: boolean;
  createdAt: string;
  owner?: User;
  _count?: { song: number; editors: number };
}

export interface CreateAlbumInput {
  name: string;
  isCollaborative?: boolean;
}

export type UpdateAlbumInput = Partial<CreateAlbumInput>;

export interface AlbumSong {
  albumId: string;
  songId: string;
  addedAt: string;
  song?: Song;
}

export interface AlbumEditor {
  albumId: string;
  userId: string;
  user?: User;
}

// ---------------------------------------------------------------------------
// ListeningSession
// ---------------------------------------------------------------------------
export interface ListeningSession {
  id: string;
  joinCode: string;
  hostId: string;
  currentSondId: string | null; // NB: typo preserved from server schema (currentSondId)
  isPlaying: boolean;
  positionSeconds: number;
  positionUpdatedAt: string;
  createdAt: string;
  host?: User;
  currentSong?: Song | null;
  _count?: { participants: number; queue: number; messages: number };
}

export interface CreateListeningSessionInput {
  currentSondId?: string;
}

export interface UpdateListeningSessionInput {
  currentSondId?: string;
  isPlaying?: boolean;
  positionSeconds?: number;
}

// ---------------------------------------------------------------------------
// SessionParticipant
// ---------------------------------------------------------------------------
export interface SessionParticipant {
  sessionID: string;
  userId: string;
  role: SessionRole;
  joinedAt: string;
  user?: User;
}

export interface JoinSessionInput {
  role?: SessionRole;
}

export interface UpdateParticipantInput {
  role: SessionRole;
}

// ---------------------------------------------------------------------------
// QueueItem
// ---------------------------------------------------------------------------
export interface QueueItem {
  id: string;
  sessionId: string;
  songId: string;
  addedById: string;
  position: number;
  createdAt: string;
  song?: Song;
  addedBy?: User;
}

export interface AddQueueItemInput {
  songId: string;
  position?: number;
}

export interface UpdateQueueItemInput {
  position: number;
}

// ---------------------------------------------------------------------------
// SessionMessage
// ---------------------------------------------------------------------------
export interface SessionMessage {
  id: string;
  sessionId: string;
  userId: string;
  type: string;
  content: string;
  createdAt: string;
  user?: User;
}

export interface CreateSessionMessageInput {
  type: "text" | "emoji" | string;
  content: string;
}

// ---------------------------------------------------------------------------
// Auth (better-auth email/password)
// ---------------------------------------------------------------------------
export interface RegisterInput {
  email: string;
  password: string;
  name: string;
}

export interface LoginInput {
  email: string;
  password: string;
}
