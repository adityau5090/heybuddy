import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { likedSongsApi } from "../api/likedSongs";
import { queryKeys } from "./queryKeys";
import type { LikedSong, PaginationQuery } from "../types/api";

export function useLikedSongs(query?: PaginationQuery) {
  return useQuery({
    queryKey: queryKeys.likedSongs.mine(query),
    queryFn: () => likedSongsApi.listMine(query),
  });
}

export function useLikeSong() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (songId: string) => likedSongsApi.like(songId),
    onMutate: async (songId) => {
      await qc.cancelQueries({ queryKey: queryKeys.likedSongs.all });
      const previous = qc.getQueriesData<{ data: LikedSong[] }>({
        queryKey: queryKeys.likedSongs.all,
      });
      // optimistic add is skipped here since we don't have full song data;
      // rely on invalidation below for correctness.
      return { previous };
    },
    onSettled: () => {
      qc.invalidateQueries({ queryKey: queryKeys.likedSongs.all });
    },
  });
}

export function useUnlikeSong() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (songId: string) => likedSongsApi.unlike(songId),
    onSettled: () => {
      qc.invalidateQueries({ queryKey: queryKeys.likedSongs.all });
    },
  });
}
